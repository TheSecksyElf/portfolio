﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CamMovement: MonoBehaviour
{
    public GameObject parent;
    public float offset = 5f;

    void Update()
    {
        Vector3 pos = parent.transform.position;
        pos.y += offset;
        this.transform.position = pos;
    }
}