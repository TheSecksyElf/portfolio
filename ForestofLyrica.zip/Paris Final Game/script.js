//Script for character stat sheet Strongholds and Centaurs
/*eslint-env browser*/
/*eslint-disable-next-line no-console*/

//Game variables
var stat = 0;

var power = 0;
var nimble = 0;
var dispo = 0;
var acumen = 0;
var prude = 0;

var rollOne = 0;
var rollTwo = 0;
var rollThree = 0;

var statCount = 0;
var pipe = false;
//var accept = false;
var output = document.getElementById("output");
output.innerHTML = "You get 3 rolls of each stat. <br> If you like your roll, click ''I like this number!'' and you will lock it in. <br> The third number will auto-lock, so be careful! <br><br> Once you're done applying stats, click ''Finalize'' to lock it in!<br> You can click the refresh button to start again at any time."

var header = document.getElementById("header");

var current = document.getElementById("current");
current.innerHTML = "Your current roll will show up here."

var powerText = document.getElementById("powerText");
var powerText2 = document.getElementById("powerText2");
powerText.innerHTML = "Power:";

var nimbleText = document.getElementById("nimbleText");
var nimbleText2 = document.getElementById("nimbleText2");
nimbleText.innerHTML = "Nimbleness:";

var dispoText = document.getElementById("dispoText");
var dispoText2 = document.getElementById("dispoText2");
dispoText.innerHTML = "Disposition:";

var acumenText = document.getElementById("acumenText");
var acumenText2 = document.getElementById("acumenText2");
acumenText.innerHTML = "Acumen:";

var prudeText = document.getElementById("prudeText");
var prudeText2 = document.getElementById("prudeText2");
prudeText.innerHTML = "Prudence:";

//button
var diceRoll = document.getElementById("diceRoll");
diceRoll.addEventListener("click", clickHandler, false);

var chosenRoll = document.getElementById("chosenRoll");
chosenRoll.addEventListener("click", clickHandle2, false);
chosenRoll.disabled = true;

var finalize = document.getElementById("finalize");
finalize.addEventListener("click", FinalizeMe, false);
document.getElementById("finalize").disabled = true;

var refresh = document.getElementById("refresh");
refresh.addEventListener("click", Refresh, false);

var startgame = document.getElementById("startgame");
startgame.addEventListener("click", startGame, false);
document.getElementById("startgame").disabled = true;

var dice1 = document.getElementById("dice1");
var dice2 = document.getElementById("dice2");
var dice3 = document.getElementById("dice3");
var breaks = document.getElementById("break");

var charsheet = document.getElementById("charsheet");
document.getElementById("game").style.display = "none";
//Create an array for the map
var map = [];

map[0] = "There are some large pipes leading from the ceiling down the wall.";
map[1] = "A large steel door. There's a numberpad next to it labelled 'EXIT-EMERGENCY USE ONLY'.";
map[2] = "A camera is in the corner, just out of reach. A red light is flashing.";
map[3] = "A long pipe reaches across the cieling.";
map[4] = "The middle of a massive room. There's a carpet on the floor with a weird pattern.";
map[5] = "A power box sits on the wall, with wires leading out of it.";
map[6] = "There is a lone vent in the corner. Piping reaches around the cieling.";
map[7] = "There is a computer sitting on a small desk.";
map[8] = "A creepy skeleton sits in the corner of the room.";
map[9] = "An empty room.";

//Player's starting location
var mapLocation = 4;

//Array of images. 
var images = [];

//Pass items into the array. These are the filenames of the images. //Watch spelling!
images[0] = "pipe.png";
images[1] = "frontdoor.png";
images[2] = "camera.png";
images[3] = "pipelong.png";
images[4] = "carpet.png";
images[5] = "powerbox.png";
images[6] = "vent.png";
images[7] = "computron.png";
images[8] = "skeleman.png";
images[9] = "eroom.png";

//Create an empty array to hold the blocked path warnings
var blockedPathMessages = [];

blockedPathMessages[0] = "Unless you're superhuman, you aren't getting through this concrete wall.";
blockedPathMessages[1] = "Unless you're superhuman, you aren't getting through this concrete wall.";
blockedPathMessages[2] = "Unless you're superhuman, you aren't getting through this concrete wall.";
blockedPathMessages[3] = "There is no way through this wall...";
blockedPathMessages[4] = "";
blockedPathMessages[5] = "Unless you're superhuman, you aren't getting through this concrete wall.";
blockedPathMessages[6] = "Unless you're superhuman, you aren't getting through this concrete wall.";
blockedPathMessages[7] = "Unless you're superhuman, you aren't getting through this concrete wall.";
blockedPathMessages[8] = "Unless you're superhuman, you aren't getting through this concrete wall.";
blockedPathMessages[9] = "Unless you're superhuman, you aren't getting through this concrete wall.";

//An array of Strings to display hints at specific locations where items are required for progression
var helpMessages = [];

helpMessages[0] = "The piping is loose... it's just out of reach though.";
helpMessages[1] = "It looks like you need a code.";
helpMessages[2] = "You don't want to be caught escaping...";
helpMessages[3] = "This wall is oddly... empty.";
helpMessages[4] = "This carpet looks.. out of place.";
helpMessages[5] = "You may need a key.";
helpMessages[6] = "You may need a tool.";
helpMessages[7] = "This may help with the pipe...";
helpMessages[8] = "if you take something, I'm sure they won't miss it!";
helpMessages[9] = "It's an empty room. congrats on finding it though!";


//Two arrays to hold item names and item locations, only one item is in the game world by default
//The rest are acquired by player action.
//Therefore, we are going to expand these arrays later
var items = [];
var itemLocations = [];

var openDoor = false;
var powerLock = true;
var stool = false;
var camOn = true;
var secretLocation = false;
var carpetButton = false;
var computerOn = false;
//Empty array for the player inventory
var backpack = [];

//Variable to store the player's input
var playersInput = "";

//Game Message String
var gameMessage = "<br>Welcome to The Subspace Prison. Escape. We dare you."
//Append to the gameMessage
gameMessage += "Try any of these words: "
gameMessage += "north, south, east, west, take, drop, use, inspect, help";

//An array of actions that the player can do
var actionsIKnow = ["north","east","south","west","help","take","push", "use","drop", "inspect", "numpad", "24153"];

//Variable for the current action
var action = "";

//An array of items in the game
var itemsIKnow = ["pipe", "computer", "table", "key", "screwdriver", "button", ];

//Blank string to store the current item
var item = "";

//HTML reference variables
var image = document.querySelector("img");

var outputgame = document.querySelector("#output2");
var input = document.querySelector("#input");

var button = document.querySelector("#enter");

//Add a click event to the button
button.addEventListener("click",nextAction, false);

document.addEventListener("keydown", function(event) {
   if (event.keyCode === 13) {playGame();}
});
var trainPower = document.getElementById("trainpower");
trainPower.addEventListener("click", TrainPower, false);
trainPower.disabled = true;

var trainNimble = document.getElementById("trainnimble");
trainNimble.addEventListener("click", TrainNimble, false);
trainNimble.disabled = true;

var trainDispo = document.getElementById("traindispo");
trainDispo.addEventListener("click", TrainDispo, false);
trainDispo.disabled = true;

var trainAcumen = document.getElementById("trainacumen");
trainAcumen.addEventListener("click", TrainAcumen, false);
trainAcumen.disabled = true;

var trainPrude = document.getElementById("trainprude");
trainPrude.addEventListener("click", TrainPrude, false);
trainPrude.disabled = true;

//Run the render function first.
rendergame();

function TrainPower(){
    if (power < 20){
        power++;
        playGame();
    }
}
function TrainNimble(){
    if (nimble < 20){
        nimble++;
        playGame();
    }
}
function TrainDispo(){
    if (dispo < 20){
        dispo++;
        playGame();
    }
}
function TrainAcumen(){
    if (acumen < 20){
        acumen++;
        playGame();
    }
}
function TrainPrude(){
    if (prude < 20){
        prude++;
        playGame();
    }
}

function nextAction() {
    playGame();
}

function playGame() {
    //Get the player's input and convert it to all lower case
    playersInput = input.value;
    playersInput = playersInput.toLowerCase();
    
    //Reset the game variables from the previous turn
    gameMessage = "";
    action = "";
    
    //Figure out what the player's action is
    //Iterate over all the possible actions
    for (var i = 0; i < actionsIKnow.length; i++) {
        
        //Check this if statement in the loop
        //"If what the player entered can be found in the actionsIKnow array"
        if (playersInput.indexOf(actionsIKnow[i]) !== -1) {
            //Set the current action to be whatever the player typed
            action = actionsIKnow[i];
            
            console.log("Player's Action: " + action);
            break; //If the parameters are met, stop checking
        }
    }
    
    //Secondary for loop to check if the player has used any item-related commands
    //Logic here is the same as actions, but specific to items!
    for (var i = 0; i < itemsIKnow.length; i++) {
        if (playersInput.indexOf(itemsIKnow[i]) !== -1) {
            item = itemsIKnow[i];
            console.log("player's item: " + item);
        }
    }
    
    //Choose the right action and do the thing!
    switch(action) {            
        case "north":
            if (mapLocation >= 3 && mapLocation !=9) {
                mapLocation -= 3;
            }
            else {
                gameMessage = blockedPathMessages[mapLocation];
            }
            break;
        
        case "east":
            if (mapLocation % 3 != 2 && mapLocation !=9) {
                mapLocation += 1;
            }
            else if (mapLocation == 9){
                mapLocation = 3;
            }
            else {
                gameMessage = blockedPathMessages[mapLocation];
            }
            break;
        
        case "south":
            if (mapLocation < 6 && mapLocation !=9) {
                mapLocation += 3;
            }
            else {
                gameMessage = blockedPathMessages[mapLocation];
            }
            break;
            
        case "west":
            //Locations 0, 3, and 6 will give a remainder of 0 when divided by 3
            if (mapLocation % 3 != 0 && mapLocation !=9 && secretLocation == false) {
                mapLocation -= 1;
            }
            else if (mapLocation == 3 && secretLocation == true){
                mapLocation = 9;
            }
            else {
                gameMessage = blockedPathMessages[mapLocation];
            }
            break;
            
        case "help":
            //If the helpMessage array at the current location is not empty, display the message
            if (helpMessages[mapLocation] !== "") {
                gameMessage = helpMessages[mapLocation] + " ";
            }
            
            //Add this at the end of the message, whether it's blank or not!
            gameMessage += "Try any of these words: "
            gameMessage += "north, east, south, west, take, drop, use, inspect";
            
            break;
            
        case "take":
            takeItem();
            break;
            
        case "drop":
            dropItem();
            break;
            
        case "use":
            useItem();
            break;
        
        case "numpad":
            if (mapLocation === 1){
                gameMessage = "Please input code.";
            } 
            else{
                gameMessage = "There isn't any place to input the code here!";
            }
            break;
        case "24153":
            if (mapLocation === 1&&power>15){
                gameMessage = "The door starts to slide open... but it gets stuck. You force it open with your power. You see a massive guard, but he hasn't noticed you yet.";
                gameMessage += "wait- are those airpods?";
                openDoor = true;
                trainAcumen.disabled = false;
            }
            else if (mapLocation ===1&&power<15){
                gameMessage = "The door starts to skide open... but it gets stuck. You try to force it open, but you're too weak. you need to train your POWER.";
                gameMessage+= "the door slides closed once more.";
            }
            else{
                gameMessage = "I do not understand that!";
            }
        break;
            
        case "push":
            if (mapLocation === 3 && secretLocation == true){
                mapLocation = 9;
            }
            else if (mapLocation == 9){
                mapLocation = 3;
            }
            else if (mapLocation === 5 && powerLock == false){
                gameMessage = "you turned the power off. You hear a computer whirring from another part of the room...";
                items.push("computer", "table");
                itemLocations.push(7, 7);
                trainDispo.disabled = false;
                map[7] = "There is a computer here with a red fish on it's screen. Wonder what that means...";
                map[2] = "The camera is turned off. There are no lights. in fact, the only light is from the numpad...";
            }
            else{
                gameMessage = "Nothing happened.";
            }
            break;
        
        case "inspect":
            if (mapLocation === 0){
                gameMessage = "A portion of the pipe is broken, but it's just out of reach.";
                if (stool == true){
                    gameMessage += "Don't you have something to stand on?";
                }
            }
            else if (mapLocation === 1){
                if (openDoor == false){
                        gameMessage = "The Keypad says 'please enter password.'";
                    }
                else if (openDoor == true){
                   gameMessage = "You see the back of a 7-foot tall guard. He hasn't moved, there are airpods in his ears.";
                }
   
            }
            else if (mapLocation === 2){
                if (camOn == true){
                    gameMessage = "Upon closer inspection, the camera seems to be following your every move.";
                }
                else if (camOn == false){
                    gameMessage = "The camera light stopped flashing, and the camera shutter is closed." ;   
                }
 
            }
            else if (mapLocation === 3){
                if (secretLocation == false){
                    gameMessage = "This wall looks suspiciously empty...";
                }
                else if (secretLocation == true){
                    gameMessage = "A passage to another room is hidden in the wall.";
                }
            }
            else if (mapLocation === 4){
                if (carpetButton == false){
                    gameMessage = "You move the carpet... and there's a button underneath! (Take the button, you may need it!)";
                    carpetButton = true;
                    items.push("button");
                    itemLocations.push(mapLocation);
                    
                    helpMessages[mapLocation] = "pick up the button!";
                }
                else gameMessage = "There's nothing to inspect...";
            } 
            else if (mapLocation === 5){
                if (powerLock == true){
                    gameMessage = "The box is locked...";
                }
                else if (powerLock == false){
                    gameMessage = "You see a 'master power' switch in the box.";
                }                
            }
            else if (mapLocation === 6){
                gameMessage = "The vent is kinda loose. Maybe there's a screwdriver nearby.";
            }
            else if (mapLocation === 7){
                if (computerOn == false){
                gameMessage = "the computer has no power to it... it's kind of useless. The table looks like you could stand on it though.";
                }
                else if (computerOn == true){
                    gameMessage = "There's a nice red fish as a background screen. Hm.. wonder what that could mean."
                }
            }
            else if (mapLocation === 8){
                gameMessage = "The skeleton looks like it's holding some sort of screwdriver.";
                    items.push("screwdriver");
                    itemLocations.push(mapLocation);
            }
            else if (mapLocation === 9){
                gameMessage = "The room is empty. Good job finding it though!";
            }
            break;
            
        default:
            gameMessage = "I do not understand that!";
            
    }
    powerText2.innerHTML = "Power:" + power;
    nimbleText2.innerHTML = "Nimbleness:" + nimble;
    dispoText2.innerHTML = "Disposition:" + dispo;
    acumenText2.innerHTML = "Acumen:" + acumen;
    prudeText2.innerHTML = "Prudence:" + prude;
    
    //Call the render function no matter what!
    rendergame();

}

function takeItem() {
    //Find the index number of the item in the items array and store in a local variable
    var itemIndexNumber = items.indexOf(item);
    
    //Does the item exist in the game world AND is it at the player's current location?
    if (itemIndexNumber !== -1 && itemLocations[itemIndexNumber] === mapLocation) {
           gameMessage = "You got the " + item + "!";
        
        //Add the item to the player's inventory
        backpack.push(item);
        
        //Remove from the game world at the location
        //Splice removes the item, the second number tells how many to remove
        items.splice(itemIndexNumber, 1);
        itemLocations.splice(itemIndexNumber, 1);
        
        console.log("World items: " + items);
        console.log("Current inventory: " + backpack);
    }
    else {
        gameMessage = "You can't do that!";
    }
}

function dropItem() {
    //First check to make sure that the backpack array is not empty
    if (backpack.length !== 0) {
        //Find the item's array index number in the backpack and store it in a local var
        var backpackIndexNumber = backpack.indexOf(item);
        
        //If the item is in your backpack
        if (backpackIndexNumber !== -1) {
            gameMessage = "You drop the " + item + ".";
            
            //Add the item back to the game world
            items.push(backpack[backpackIndexNumber]);
            itemLocations.push(mapLocation);
            
            //Remove from the backpack`
            backpack.splice(backpackIndexNumber, 1);
            
        }
        else {
            gameMessage = "You can't do that!";
        }
    }
    else {
        gameMessage = "Your backpack is empty!";
    }
}

function useItem() {
    //Step 1. Find out if the item is in the backpack array
    
    //Find the item array index number in the backpack, store in a local var
    var backpackIndexNumber = backpack.indexOf(item);
    
    //Make sure the item the player asked for is actually there
    if (backpackIndexNumber === -1) {
        gameMessage = "You aren't carrying that!";
    }
    
    //Check if there are items in the backpack at all
    if (backpack.length === 0) {
        gameMessage += "Your backpack is empty!";
    }
    
    //Step 2. If the item is in the backpack, what do?
    
    //If the item is found in your backpack
    if (backpackIndexNumber !== -1) {
        switch (item) {  
            case "key":
                if (mapLocation === 5 && powerLock == true){
                    gameMessage = "You unlocked the box! Time to mess with wires!"
                    powerLock = false;
                }
                else if (mapLocation === 5 && powerLock == false){
                    gameMessage = "You already unlocked it. why would you lock it again?";
                }
                else{
                    gameMessage = "you poke it with a key. nothing happens.";
                }
                break;
            case "pipe":
                if (mapLocation === 1 && power>19 && acumen>19 && dispo>19 && prude>19 && nimble>19) {
                    gameMessage = "You swing the pipe.";
                    if (openDoor == true){
                        gameMessage += "The guard at the door is taken by surprise! You knock him out.";
                        gameMessage += "Congratulations! You escaped!!!!"
                        trainAcumen.disabled = true;
                        trainDispo.disabled = true;
                        trainPower.disabled = true;
                        trainNimble.disabled = true;
                        trainPrude.disabled = true;
                        button.disabled = true;
                        input.disabled =true;
                        
                    }                                        
                    helpMessages[mapLocation] = "";
                }
                else if (mapLocation === 1 && power<20 && acumen<20 && dispo<20 && prude<20 && nimble<20){
                    gameMessage = "Your stats aren't good enough. Go TRAIN harder.";
                }
                else {
                    gameMessage = "You swing the pipe.";
                    gameMessage += "..you look stupid. stop swinging.";
                }
            break;
                   
            case "table":
                if (mapLocation === 0 && pipe == false) {
                    gameMessage = "You place the table down and use it as a step.";
                    gameMessage += "Almost falling backwards, you pull the pipe and it falls to the floor."
                    gameMessage += "<br>Congrats! You're now a criminal.";
                    
                    //Remove the stone from your inventory
                    backpack.splice(backpackIndexNumber, 1);
                    
                    //Add the flute to the game world at the current map location
                    items.push("pipe");
                    itemLocations.push(mapLocation);
                    pipe = true;
                    trainPower.disabled = false;
                    
                    helpMessages[mapLocation] = "there's nothing left here. unless you forgot to pick up the pipe.";
                }
                else {
                    gameMessage = "..nice table. put it away.";
                }
            break;            
            
            case "computer":
                if (mapLocation === 0 && pipe == false) {
                    gameMessage = "You place the computer down and use it as a step.";
                    gameMessage += "Almost falling backwards, you pull the pipe and it falls to the floor."
                    gameMessage += "<br>Congrats! You're now a criminal, AND you broke an expensive computer. Are you proud of yourself?";
                    
                    //Remove the stone from your inventory
                    backpack.splice(backpackIndexNumber, 1);
                    
                    //Add the flute to the game world at the current map location
                    items.push("pipe");
                    pipe = true;
                    itemLocations.push(mapLocation);
                    trainPower.disabled = false;
                    
                    helpMessages[mapLocation] = "there's nothing left here. unless you forgot to pick up the pipe.";
                }
                else {
                    gameMessage = "damn.. a nice red herring.";
                }
            break;
                
            case "button":
                if (mapLocation === 3){
                    gameMessage = "You hear a rumbling, and the wall pushes open.";
                    gameMessage += "You found a secret room!";
                    trainNimble.disabled = false;
                    backpack.splice(backpackIndexNumber, 1);
                    helpMessages[mapLocation] = "There's a secret passage here! Push to enter!";
                    secretLocation = true;
                }
                break;
            
            case "screwdriver":
                if (mapLocation === 6) {
                    gameMessage = "You use the screwdriver on the loose vent screws.";
                    gameMessage += "You reach in and find a key! You dropped it cuz it was kinda hot.";
                    trainPrude.disabled = false;
                    backpack.splice(backpackIndexNumber, 1);
                    items.push("key");
                    itemLocations.push(mapLocation);
                    
                }
                else {
                    gameMessage = "you poke the thing with the screwdriver. nothing happened.";
                }
            break;
        }
    }
}

function rendergame() {
    //Write the area descriptions based on the map[]. The index number will be updating based on user commands. Default is map[4]
    outputgame.innerHTML = map[mapLocation];
    
    //Set the image source using the same method. The image array will always update based on the mapLocation index
    image.src = "img/" + images[mapLocation];
    
    //Display an item in the gameMessage if it is at the current location
    //Loop through all the items and check for a match
    for (var i = 0; i < items.length; i++) {
        if (mapLocation === itemLocations[i]) {
            //If an item is found at that location, display it in the output
            outputgame.innerHTML += "You see a <strong>" + items[i] + "</strong> here.";
        }
    }
    
    if (backpack.length !== 0) {
        //Display all the items in the backpack.
        //backpack.join will combine all the strings in an array. The parameters ask for a separator
        //In this case, a comma.
        outputgame.innerHTML += "<br>You are carrying: " + backpack.join(", ");
    }
    
    //Display the game message at the end of the output description.
    //Add a line break <br> and emphasize <em> the message.
    outputgame.innerHTML += "<br><em>" + gameMessage + "</em>";
    
    //Clear the input field
    input.value = "";
}

function clickHandler(){
    randomize();    
}
function clickHandle2(){
    finalizeStat();
}
function FinalizeMe(){
    var playerName = document.getElementById("playerName");
    var name = playerName.value;
    if (name !="" && statCount == 16){
        console.log(statCount);
        Results();
    }
    else if (name == ""){
        window.alert("You need a name!");
    }
    else{
        console.log (statCount);
        
    }
}
function Refresh(){
    window.location.reload();
}

function render(){
    dice1.style.backgroundImage = "url(img/dice-" + rollOne +".png)";
    dice2.style.backgroundImage = "url(img/dice-" + rollTwo +".png)";
    dice3.style.backgroundImage = "url(img/dice-" + rollThree +".png)";
}

function randomize(){
    chosenRoll.disabled = false;
    statCount+=1;
    if (statCount >= 16){
        document.getElementById("diceRoll").disabled = true;
        document.getElementById("finalize").disabled = false;
    }
    else {
        rollOne = Math.ceil(Math.random()*6);
        rollTwo = Math.ceil(Math.random()*6);
        rollThree = Math.ceil(Math.random()*6);
        render();
        stat = rollOne + rollTwo + rollThree;
        current.textContent = "Your current roll is " + stat;

    
        if (statCount == 3){insertPower();}
        if (statCount == 6){insertNimble();}
        if (statCount == 9){insertDispo();}
        if (statCount == 12){insertAcumen();}
        if (statCount == 15){insertPrude();}
    }

}

function insertPower(){
    power = stat;
    stat = 0;
    document.getElementById("chosenRoll").disabled = true;
    document.getElementById("diceRoll").textContent = "Roll for Nimbleness"
    powerText.textContent = "Power =" + power;
}
function insertNimble(){
    nimble = stat;
    stat = 0;
    document.getElementById("chosenRoll").disabled = true;
    document.getElementById("diceRoll").textContent = "Roll for Disposition"
    nimbleText.textContent = "Nimbleness =" + nimble;
}
function insertDispo(){
    dispo = stat;
    stat = 0;
    document.getElementById("chosenRoll").disabled = true;    
    document.getElementById("diceRoll").textContent = "Roll for Acumen"
        dispoText.textContent = "Disposition = " + dispo;
}
function insertAcumen(){
    acumen = stat;
    stat = 0;
    document.getElementById("chosenRoll").disabled = true;
    document.getElementById("diceRoll").textContent = "Roll for Prudence"
    acumenText.textContent = "Acumen = " + acumen;
}
function insertPrude(){
    prude = stat;
    stat = prude;
    document.getElementById("diceRoll").disabled = true;
    document.getElementById("finalize").disabled = false;
    document.getElementById("chosenRoll").disabled = true;
    prudeText.textContent = "Prudence =" + prude;
    statCount = 16;
}
function finalizeStat(){
    chosenRoll.disabled = true;
    if (statCount >=13 && statCount <=15){
        insertPrude();
      statCount = 16;  
    }
    else if (statCount >=10 && statCount <=12){
            insertAcumen();
      statCount = 12;  
    }
    else if (statCount >=7 && statCount <=9){
            insertDispo();
      statCount = 9;  
    }
   else if (statCount >=4 && statCount <=6){
            insertNimble();
      statCount = 6;  
    }
    else if (statCount >=1 && statCount <=3){
            insertPower();
      statCount = 3;  
    }
    else if (statCount >=16){
       chosenRoll.removeEventListener("click", clickHandler, false); 
    }
}
function Results(){
    var playerName = document.getElementById("playerName");
    var name = playerName.value;
    
    breaks.remove();
    
    header.innerHTML = "<center>"+name+"</center>";
    window.alert("Your Name is " + name +". Power = " + power + " Nimbleness = " + nimble + " Disposition = " + dispo + " Acumen = " + acumen + " Prudence = " +prude);
    playerName.disabled = true;
    finalize.removeEventListener("click", FinalizeMe, false);
    document.getElementById("finalize").disabled = true;
    document.getElementById("startgame").disabled = false;
    chosenRoll.removeEventListener("click", clickHandle2, false);
    diceRoll.removeEventListener("click", clickHandler, false);
    
    var maincharacter = {
        "name": name,
        "stats":{
            "power": power,
            "nimble": nimble,
            "dispo": dispo,
            "acumen": acumen,
            "prude": prude
        }
    }
    
}
function startGame(){
    charsheet.style.display = "none";
    document.getElementById("game").style.display = "block";
    
    powerText2.innerHTML = "Power:" + power;
    nimbleText2.innerHTML = "Nimbleness:" + nimble;
    dispoText2.innerHTML = "Disposition:" + dispo;
    acumenText2.innerHTML = "Acumen:" + acumen;
    prudeText2.innerHTML = "Prudence:" + prude;
}